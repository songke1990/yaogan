import cv2 as cv
import numpy as np
from keras.models import load_model
import numpy as np
from keras.models import Sequential
from keras.layers import Dense,Activation
from keras import optimizers
from osgeo import gdal_array

def process():
    x_train_src = r"D:\yaogan\data\imge.tif"
    y_train_src = r"D:\yaogan\data\ROI.tif"
    x_test_src = r"D:\yaogan\data\source.tif"
    y_test_src = r"D:\yaogan\data\sROI.tif"

    x_train = gdal_array.LoadFile(x_train_src)
    y_train = gdal_array.LoadFile(y_train_src)

    x_test = gdal_array.LoadFile(x_test_src)
    y_test = gdal_array.LoadFile(y_test_src)
    w, rows, cols = x_train.shape[:]
    yrows, ycols = y_train.shape[:]

    xtrain=x_train.reshape((rows * cols, 3))
    ytrain=y_train.reshape((yrows * ycols, 1))

    w,rows, cols = x_test.shape[:]
    srows, scols = y_test.shape[:]
    xtest=x_test.reshape((rows * cols, 3))
    ytest=y_test.reshape((srows * scols, 1))

    np.save(r"D:\yaogan\data\xtrain.npy",xtrain)
    np.save(r"D:\yaogan\data\ytrain.npy",ytrain)
    np.save(r"D:\yaogan\data\xtest.npy",xtest)
    np.save(r"D:\yaogan\data\ytest.npy",ytest)

def train():
    xtrain= np.load("xtrain.npy")
    ytrain= np.load("ytrain.npy")
    xtest= np.load("xtest.npy")
    ytest = np.load("ytest.npy")
    hap=Sequential()
    hap.add(Dense(256,activation='relu',input_shape=(3,)))
    hap.add(Dense(128,activation='relu'))
    hap.add(Dense(64,activation='relu'))
    hap.add(Dense(32,activation='relu'))
    hap.add(Dense(16,activation='relu'))
    hap.add(Dense(1,activation='sigmoid'))
    hap.compile(optimizer=optimizers.SGD(),loss="binary_crossentropy",metrics=['accuracy'])
    hap.fit(xtrain,ytrain,epochs=1,validation_data=(xtest,ytest))
    hap.save('model.h5')

def predict():
    x= np.load("xtrain.npy")
    model = load_model('model.h5')
    pr= model.predict(x)
    cv.imshow('pr',pr)
if __name__ == '__main__':
    process()
    train()
    predict()