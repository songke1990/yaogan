﻿# 导入cv模块
import cv2 as cv
import numpy as np
from osgeo import gdal_array

img = cv.imread(r"D:\yaogan\data\stretched.tif")
roi=img[2000:5692,3000:5585]
cv.imshow('roi',roi)
imge = cv.resize(roi, (0, 0), fx=0.3, fy=0.3, interpolation=cv.INTER_NEAREST)
cv.imwrite(r"D:\yaogan\data\imge.tif",imge)
gray = cv.cvtColor(imge, cv.COLOR_BGR2GRAY)
ret, th = cv.threshold(gray, 120, 255, cv.THRESH_BINARY)
kernel = cv.getStructuringElement(cv.MORPH_RECT, (7,7))
dil = cv.dilate(th, kernel, iterations=6)
er = cv.erode(dil, kernel, iterations=5)
er=255-er
_, contours, hierarchy = cv.findContours(er, cv.RETR_TREE, cv.CHAIN_APPROX_NONE)
ROI = np.zeros(er.shape, np.uint8)
cv.drawContours(ROI,contours, -1, (255, 255, 255), 1)

cv.imwrite(r"D:\yaogan\data\ROI.tif",ROI)



